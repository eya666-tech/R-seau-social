<?php
try
{
    $bdd = new PDO(
        'mysql:host=localhost;dbname=reseau_social;charset=utf8mb4',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}
catch (PDOException $e)
{
    die('Erreur:' . $e->getMessage());
}

/* ---------- fonctions utilitaires (communes à tout le projet) ---------- */

// échapper l'affichage (protection XSS)
if (!function_exists('e')) {
    function e($valeur)
    {
        return htmlspecialchars((string)$valeur, ENT_QUOTES, 'UTF-8');
    }
}

// URL d'une image de profil (image par défaut si absente)
if (!function_exists('imageUrl')) {
    function imageUrl($image)
    {
        $image = basename((string)$image);
        if ($image !== '' && file_exists(__DIR__ . '/../uploads/' . $image)) {
            return '../uploads/' . rawurlencode($image);
        }
        return '../images/photo.jpg';
    }
}

// afficher un message puis revenir à la page précédente
if (!function_exists('alerteEtRetour')) {
    function alerteEtRetour($message)
    {
        echo '<script>alert(' . json_encode($message, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) . ');history.back();</script>';
        exit;
    }
}

// obliger l'utilisateur à être connecté
if (!function_exists('exigerSession')) {
    function exigerSession()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['id'])) {
            header('Location: ../vue/connexion.html');
            exit;
        }
    }
}
?>
