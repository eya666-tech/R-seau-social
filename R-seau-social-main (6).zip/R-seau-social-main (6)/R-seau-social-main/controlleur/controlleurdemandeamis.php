<?php
session_start();
require_once(__DIR__ . "/../modele/DemandeAmis.php");
require_once(__DIR__ . "/../modele/Notification.php");
require_once(__DIR__ . "/../modele/Utilisateur.php");
exigerSession();

// ---------- Envoyer une demande ----------
if(isset($_POST['envoyer']))
{
    $id_demandeur = (int)$_SESSION['id'];
    $id_recepteur = (int)($_POST['user_id'] ?? 0);

    if($id_recepteur <= 0 || !Utilisateur::GetParId($id_recepteur))
    {
        alerteEtRetour("Utilisateur introuvable");
    }

    if($id_demandeur == $id_recepteur)
    {
        alerteEtRetour("Impossible d’envoyer une demande à soi-même");
    }

    $demandestatut = DemandeAmis::verifierDemande($id_demandeur,$id_recepteur);

    if((!empty($demandestatut)) && $demandestatut['statut'] == 'ACCEPTEE')
    {
        alerteEtRetour("Impossible d’envoyer une demande si déjà amis");
    }
    elseif((!empty($demandestatut)) && $demandestatut['statut'] == 'EN_ATTENTE')
    {
        alerteEtRetour("Impossible d’envoyer plusieurs demandes identiques entre deux utilisateurs");
    }
    else
    {
        // ancienne demande refusée : on la supprime avant d'en créer une nouvelle
        if(!empty($demandestatut))
        {
            DemandeAmis::reinitialiserDemande($id_demandeur,$id_recepteur);
        }

        $id_demandeamitee = DemandeAmis::envoyerdemande($id_demandeur,$id_recepteur);

        $type = "demandeAmitié";
        Notification::Ajouternotif($id_recepteur,$id_demandeamitee,$type);
        header("Location:../vue/acceuil.php");
        exit;
    }
}

// ---------- Annuler une demande envoyée ----------
if (isset($_POST['annuler']))
{
    $id_demandeur = $_SESSION['id'];
    $id_recepteur = $_POST['user_id'] ?? 0;

    if (DemandeAmis::Annulerdemande($id_demandeur, $id_recepteur))
    {
        header("Location:../vue/acceuil.php");
        exit;
    }
    else
    {
        alerteEtRetour("Aucune demande en attente à annuler");
    }
}

// ---------- Accepter une demande reçue ----------
if(isset($_POST['accepter']))
{
    $id_demandeur = $_POST['demandeur_id'] ?? 0;
    $id_recepteur = $_SESSION['id'];

    if(DemandeAmis::Accepteedemande($id_demandeur, $id_recepteur))
    {
        $type = "demandeAcceptée";
        $id_demandeamitee = $_POST['id_demande'] ?? 0;
        Notification::Ajouternotif($id_demandeur,$id_demandeamitee,$type);
    }

    header("Location:../vue/demande.php");
    exit;
}

// ---------- Refuser une demande reçue ----------
if(isset($_POST['refuser']))
{
    $id_demandeur = $_POST['demandeur_id'] ?? 0;
    $id_recepteur = $_SESSION['id'];

    if(DemandeAmis::Rejeteedemande($id_demandeur, $id_recepteur))
    {
        $type = "demandeRefusée";
        $id_demandeamitee = $_POST['id_demande'] ?? 0;
        Notification::Ajouternotif($id_demandeur,$id_demandeamitee,$type);
    }

    header("Location:../vue/demande.php");
    exit;
}

header("Location:../vue/acceuil.php");
exit;
?>
