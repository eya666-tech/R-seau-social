<?php
session_start();
require_once(__DIR__ . "/../modele/Utilisateur.php");

// ---------- Connexion ----------
if (isset($_POST["connexion"])) {

    if (!empty($_POST['email']) && !empty($_POST['motDePasse']))
    {
        $email = trim($_POST['email']);
        $password = $_POST['motDePasse'];

        $user = Utilisateur::connection($email);

        if ($user)
        {
            if (password_verify($password, $user['motDePasse'])) {

                session_regenerate_id(true);
                $_SESSION['id'] = $user['id'];
                $_SESSION['nom'] = $user['nom'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['image'] = $user['image'];

                header("Location:../vue/acceuil.php");
                exit;
            } else {
                alerteEtRetour("Mot de passe incorrect");
            }

        } else {
            alerteEtRetour("Email introuvable");
        }

    } else {
        alerteEtRetour("Remplir tous les champs");
    }
}

// ---------- Déconnexion (bouton POST ou lien GET) ----------
if (isset($_POST["deconnexion"]) || isset($_GET["deconnexion"]))
{
    session_unset();
    session_destroy();
    header("Location:../vue/connexion.html");
    exit;
}

// accès direct sans action : retour à la page de connexion
header("Location:../vue/connexion.html");
exit;
?>
