<?php
session_start();
require_once(__DIR__ . "/../modele/Amis.php");
exigerSession();

if(isset($_POST['supprimer']))
{
    $id = $_SESSION['id'];
    $idamis = $_POST['idamis'] ?? 0;

    if(Amis::SupprimerAmis($id,$idamis))
    {
        header("Location:../vue/amisinterfce.php");
        exit;
    }
    else
    {
        alerteEtRetour("Problème au niveau de la suppression");
    }
}

header("Location:../vue/amisinterfce.php");
exit;
?>
