<?php
session_start();
require_once(__DIR__ . "/../modele/Notification.php");
exigerSession();

// marquer une notification comme lue
if (isset($_POST['lue']) && isset($_POST['lu'])) {

    Notification::marquerlueonnonlue($_POST['lu']);

    header("Location: ../vue/notiflicationsinterface.php");
    exit;
}

// marquer toutes les notifications comme lues
if (isset($_GET['mark_all']) && $_GET['mark_all'] == "ok") {
    Notification::marquertouslue($_SESSION['id']);
    header("Location: ../vue/notiflicationsinterface.php");
    exit;
}

header("Location: ../vue/notiflicationsinterface.php");
exit;
?>
