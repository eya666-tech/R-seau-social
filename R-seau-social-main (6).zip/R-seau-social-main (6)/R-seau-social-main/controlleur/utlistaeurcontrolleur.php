<?php
session_start();
require_once(__DIR__ . "/../modele/Utilisateur.php");

// enregistrer l'image téléversée dans /uploads
// retourne '' si aucune image, false si erreur, sinon le nom du fichier
function enregistrerImage()
{
    if (!isset($_FILES['image']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        return '';
    }
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        return false;
    }

    $dossier = __DIR__ . '/../uploads/';
    if (!is_dir($dossier)) {
        mkdir($dossier, 0777, true);
    }

    $nom = uniqid('img_', true) . '.' . $ext;
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $dossier . $nom)) {
        return false;
    }
    return $nom;
}

// ---------- Inscription ----------
if ( isset($_POST["inscrire"]))
 {
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $motdepasse_input = $_POST['motDePasse'] ?? '';

    if (!empty($nom) && !empty($email) && !empty($motdepasse_input)) {

        if (Utilisateur::emailExiste($email)) {
            alerteEtRetour("Cet email est déjà utilisé");
        }

        $image = enregistrerImage();
        if ($image === false) {
            alerteEtRetour("Image invalide (formats acceptés : jpg, png, gif, webp)");
        }

        $motdepasse = password_hash($motdepasse_input, PASSWORD_DEFAULT);

        $user = new Utilisateur($nom,$email,$motdepasse,$image,date("Y-m-d H:i:s"));
        $id = $user->InscriptionUtilisateurs();

         if ($id) {
            session_regenerate_id(true);
            $_SESSION['id']=$id;
            $_SESSION['nom'] = $nom;
            $_SESSION['email'] = $email;
            $_SESSION['image'] = $image;
            header("Location:../vue/acceuil.php");
            exit;
        }
        else
        {
            alerteEtRetour("Erreur lors de l'inscription");
        }
    } else
    {
        alerteEtRetour("Veuillez remplir tous les champs obligatoires");
    }
}

// ---------- Suppression du compte ----------
elseif(isset($_POST["supprimer"]))
 {
    exigerSession();
    // on utilise toujours l'id de la session (pas celui du formulaire)
    $id = $_SESSION['id'];

    if(Utilisateur::SupprimerUtlisateur($id))
    {
        session_unset();
        session_destroy();

        header("Location:../vue/utlisateurforme.php");
        exit;
    }
    else
    {
        alerteEtRetour("Erreur de suppression");
    }
}

// ---------- Modification du profil ----------
elseif(isset($_POST["modifier"]))
 {
    exigerSession();
    $id = $_SESSION['id'];
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if(!empty($nom) && !empty($email))
    {
        if (Utilisateur::emailExiste($email, $id)) {
            alerteEtRetour("Cet email est déjà utilisé");
        }

        $ancien = Utilisateur::GetParId($id);
        if (!$ancien) {
            alerteEtRetour("Utilisateur introuvable");
        }

        // mot de passe vide = on garde l'ancien
        if (!empty($_POST['motDePasse'])) {
            $motdepasse = password_hash($_POST['motDePasse'], PASSWORD_DEFAULT);
        } else {
            $motdepasse = $ancien['motDePasse'];
        }

        // pas de nouvelle image = on garde l'ancienne
        $image = enregistrerImage();
        if ($image === false) {
            alerteEtRetour("Image invalide (formats acceptés : jpg, png, gif, webp)");
        }
        if ($image === '') {
            $image = $ancien['image'];
        }

        $user = new Utilisateur($nom,$email,$motdepasse,$image,date("Y-m-d H:i:s"));

        if($user->ModifierUtilisateur($id))
        {
            $_SESSION['nom'] = $nom;
            $_SESSION['email'] = $email;
            $_SESSION['image'] = $image;

            header("Location:../vue/profil.php");
            exit;
        }
        else
        {
            alerteEtRetour("Erreur de Modification");
        }
    }
    else
    {
        alerteEtRetour("Remplir tous les champs");
    }
}

header("Location:../vue/utlisateurforme.php");
exit;
?>
